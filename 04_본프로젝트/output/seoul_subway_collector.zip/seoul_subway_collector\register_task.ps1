# Windows: 매시 정각 수집 작업 등록 (관리자 권한 불필요, 로그인 상태에서 실행)
# 사용: powershell -ExecutionPolicy Bypass -File register_task.ps1
$dir = Split-Path -Parent $MyInvocation.MyCommand.Path
$action = New-ScheduledTaskAction -Execute "$dir\run_collect.cmd" -WorkingDirectory $dir
$start = (Get-Date).Date.AddHours((Get-Date).Hour + 1)
$trigger = New-ScheduledTaskTrigger -Once -At $start -RepetitionInterval (New-TimeSpan -Hours 1) -RepetitionDuration (New-TimeSpan -Days 23)
$settings = New-ScheduledTaskSettingsSet -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -ExecutionTimeLimit (New-TimeSpan -Minutes 10)
Register-ScheduledTask -TaskName "ENDB_SubwayCollect" -Action $action -Trigger $trigger -Settings $settings -Force
