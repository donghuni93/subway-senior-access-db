@echo off
rem Windows 작업 스케줄러용 진입점. PATH의 python을 사용한다.
cd /d "%~dp0"
if not exist "data\snapshots" mkdir "data\snapshots"
python -X utf8 "src\collect.py" >> "data\snapshots\collect_stdout.log" 2>&1
