"""수집 상태 점검: 소스별 오늘/전체 스냅샷 개수, 실패 건수, 가장 긴 수집 공백.
사용: python check_snapshots.py"""
import csv
from datetime import datetime
from pathlib import Path

log = Path(__file__).parent / "data" / "snapshots" / "collect_log.csv"
if not log.exists():
    raise SystemExit("collect_log.csv가 없습니다. 아직 수집된 적이 없습니다.")
rows = list(csv.DictReader(log.open(encoding="utf-8-sig")))
today = datetime.now().date().isoformat()
for src in sorted({r["source"] for r in rows}):
    r = [x for x in rows if x["source"] == src]
    ok = [x for x in r if x["result"] == "ok"]
    times = [datetime.fromisoformat(x["collected_at"]) for x in ok]
    gap = max(((b - a).total_seconds() / 3600 for a, b in zip(times, times[1:])), default=0)
    print(f"{src}: 전체 성공 {len(ok)} / 실패 {len(r) - len(ok)} / 오늘 성공 {sum(x['collected_at'].startswith(today) for x in ok)} / 최대 공백 {gap:.1f}시간")
