#!/usr/bin/env bash
# 리눅스 서버용: cron이 호출하는 진입점
cd "$(dirname "$0")" || exit 1
mkdir -p data/snapshots
python3 src/collect.py >> data/snapshots/collect_stdout.log 2>&1
