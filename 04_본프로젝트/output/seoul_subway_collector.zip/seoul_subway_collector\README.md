# 서울 지하철 승강기·출입구 API 수집기

서울 열린데이터광장 API 3종을 매시 호출해 원본 응답을 시각별 JSON(gzip)으로 저장한다.
표준 라이브러리만 쓰므로 `pip install`이 필요 없다. Python 3.9 이상.

| source | 데이터셋 | 서비스명 | 건수(11/17) |
|---|---|---|---|
| elevator_status | OA-15994 승강기 가동현황 | SeoulMetroFaciInfo | 2,809 |
| elevator_ev | OA-22740 엘리베이터 현황 | getWksnElvtr | 871 |
| exit_closure | OA-22122 출입구 임시폐쇄 | TbSubwayLineDetail | 8 |

## 1. 준비 (공통)
1. 이 폴더를 서버에 푼다. (서버 접속 방법: 팀에서 정한 방식. SSH 또는 원격 데스크톱)
2. 인증키 파일 만들기: `.env.example`을 `.env`로 복사하고 키를 넣는다. 키는 ZIP에 들어 있지 않으니 따로 받는다.
   환경변수 `SEOUL_API_KEY`로 줘도 된다. **키를 채팅·Git에 올리지 않는다.**
3. 한 번 수동 실행해 확인한다.
   ```
   python src/collect.py        # Windows는 python, 리눅스는 python3
   ```
   `ok 2809`, `ok 871`, `ok 8`처럼 3줄이 나오면 성공이다. 서버에서 외부로 `http://openapi.seoul.go.kr:8088`(80이 아닌 8088 포트)에 접속할 수 있어야 한다. 막혀 있으면 error가 나온다.

## 2-A. 리눅스 서버: cron으로 매시 실행
```
chmod +x run_collect.sh
crontab -e
```
다음 줄을 추가한다(경로는 실제 위치로):
```
0 * * * * /home/USER/seoul_subway_collector/run_collect.sh
```
서버 시간대가 KST인지 `date`로 확인한다. 서버를 켜 두기만 하면 PC와 달리 결측이 거의 없다.

## 2-B. Windows: 작업 스케줄러로 매시 실행
```
powershell -ExecutionPolicy Bypass -File register_task.ps1
```
PC가 꺼지거나 절전이면 그 시간은 수집되지 않는다(결측). 절전 해제와 전원 연결을 권장한다.

## 3. 확인
- `data/snapshots/{source}/YYYYMMDD_HHMM.json.gz` : 원본 응답. 읽기 `gzip.open(path, "rt", encoding="utf-8")`
- `data/snapshots/collect_log.csv` : 시각, 소스, ok/error, 행 수, API 전체 건수, 메시지
- `data/snapshots/collect_stdout.log` : 실행 출력
- `python check_snapshots.py` : 소스별 성공·실패·최대 공백 요약
- 하루가 지나면 소스마다 스냅샷 24개가 쌓여야 한다.

## 4. 수집 데이터 모으기
수집이 끝나면(또는 주기적으로) `data/snapshots/` 폴더를 통째로 압축해 팀 PC로 가져온다. 용량은 1회 약 58KB, 3주 약 30MB.
두 곳에서 수집했다면 같은 이름의 파일이 겹치지 않는지(시각이 다르므로 보통 겹치지 않음) 확인하고 합친다.

## 5. 문제 해결
| 증상 | 원인·조치 |
|---|---|
| `SEOUL_API_KEY가 없습니다` | `.env` 위치(이 폴더)와 줄 형식 `SEOUL_API_KEY=키` 확인 |
| error `INFO-100` | 인증키 오류. 키 재확인 |
| error `ERROR-337` 등 | 일일 호출 한도 초과. 매시 3회 정도라 정상 사용에서는 나오지 않음 |
| error `행 수 불일치` | 수집 중 데이터가 바뀜. 다음 정시에 자동 재시도됨 |
| 타임아웃·연결 실패 | 서버의 외부 접속 제한. 8088 포트 허용 필요 |
| 테스트 | `python -m pytest tests` (pytest 설치 필요, 선택) |
